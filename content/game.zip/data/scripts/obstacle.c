void main()
{
    void self = getlocalvar("self"); // Get the caller
    int animId = getentityproperty(self, "animationid"); // Get the caller's animation ID
    
    // Check if the caller is in ANI_IDLE
    if (animId == openborconstant("ANI_IDLE"))
    {
        void opp = getentityproperty(self, "opponent"); // Gets who is attacking it
        int direction = getentityproperty(opp, "direction"); // Gets opponent facing
        
        if (direction == 1) performattack(self, openborconstant("ANI_FOLLOW1")); // Is entity facing right?
        if (direction == 0) performattack(self, openborconstant("ANI_FOLLOW2")); // Is entity facing left?
    }
}